public class Element {

    private int weight;
    private int value;

    public Element(int weight, int value){
        this.weight=weight;
        this.value =value;
    }


    public int getWeight(){
        return weight;
    }

    public int getValue(){
        return value;
    }

}
