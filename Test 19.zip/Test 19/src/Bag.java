import java.util.List;

public class Bag {

    List<Element> elements;
    int totalElementsValue;

    public Bag(List<Element> elements, int totalValue) {
        this.elements = elements;
        this.totalElementsValue = totalValue;
    }
}
